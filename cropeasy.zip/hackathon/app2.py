from flask import Flask, request, render_template, jsonify
import pandas as pd
import joblib
import requests
from geopy.geocoders import Nominatim

model = joblib.load('crop_prediction_model1_v2.pkl')
scaler = joblib.load('scaler1_v2.pkl')

app = Flask(__name__)
geolocator = Nominatim(user_agent="crop_recommendation_app")

# Load the data
data = pd.read_csv('Fertilizer.csv')
data['Crop'] = data['Crop'].apply(lambda x: x.split('(')[0].strip())

fertilizer_dic = {
    'NHigh': [
        "మీ మట్టిలో N విలువ అధికంగా ఉంది మరియు కలుపు మొక్కలు ఉత్పన్నమవుతాయి.",
        "పేడను జోడించండి.",
        "కాఫీ గ్రిండ్‌లు ఉపయోగించండి.",
        "నైట్రోజన్ స.fix.స్.క మొక్కలు నాటండి.",
        "హరిత పేడ పంటలు నాటండి.",
        "పంటలను పెంచేటప్పుడు మల్చ్ ఉపయోగించండి."
    ],
    'Nlow': [
        "మీ మట్టిలో N విలువ తక్కువగా ఉంది.",
        "సాదస్ట్ను లేదా తేలికపాటి చెక్కలను జోడించండి.",
        "బరువైన నైట్రోజన్ తినే మొక్కలను నాటండి.",
        "నీటితో రాచడం.",
        "చక్కర జోడించండి.",
        "మట్టిలో కంపోస్ట్ చేయబడిన పేడను జోడించండి.",
        "నైట్రోజన్ స.fix.స్.క మొక్కలు నాటండి.",
        "ఎన్పీకే ఫర్టిలైజర్లు అధిక N విలువతో ఉపయోగించండి.",
        "ఏమీ చేయవద్దు."
    ],
    'PHigh': [
        "మీ మట్టిలో P విలువ అధికంగా ఉంది.",
        "పేడను జోడించడం నివారించండి.",
        "పాస్పరస్-రహిత ఎరువు ఉపయోగించండి.",
        "మీ మట్టిని నీటితో రాచండి.",
        "పాస్పరస్ పెంచకుండా నైట్రోజన్ పెంచడానికి పుష్టికర కూరగాయలను నాటండి.",
        "పాస్పరస్ స్థాయిలను తగ్గించడానికి పంటలు మారుస్తూ ఉండండి."
    ],
    'Plow': [
        "మీ మట్టిలో P విలువ తక్కువగా ఉంది.",
        "ఎముకల పిండం జోడించండి.",
        "రాక్ ఫాస్పేట్ ఉపయోగించండి.",
        "ఫాస్పరస్ ఎరువులు ఉపయోగించండి.",
        "సేంద్రియ కంపోస్ట్ జోడించండి.",
        "పేడ జోడించండి.",
        "మట్టిలో మట్టిని జోడించండి.",
        "మట్టిని సరైన pHలో ఉంచండి.",
        "మట్టిలో pH తక్కువగా ఉంటే, చునాకు లేదా పొటాషియం కార్బోనేట్‌ను జోడించండి.",
        "pH అధికంగా ఉంటే, ఆమ్లీకరించే ఎరువులు జోడించండి."
    ],
    'KHigh': [
        "మీ మట్టిలో K విలువ అధికంగా ఉంది.",
        "పేడను జోడించడం నివారించండి.",
        "పొటాషియం నిత్యాహారాలను నాటండి.",
        "పొటాషియం నియామక సిలిండరులు నాటండి.",
        "కాస్టర్ ఎరువులు నాటండి.",
        "మినరల్ రాక్ మరియు కాస్టర్ ఎరువులు నాటండి.",
        "నాటి పారుదలో పొటాషియం నిత్యాహారాలను నాటండి."
    ],
    'Klow': [
        "మీ మట్టిలో K విలువ తక్కువగా ఉంది.",
        "కాస్టర్ ఎరువులు నాటండి.",
        "పేడను జోడించండి.",
        "నైట్రోజన్ మరియు పొటాషియం ప్రయోగించే ఎరువులు నాటండి.",
        "మీ మట్టిలో ఫాస్ఫరస్ లేదా కాల్షియం ఉంటే, అవి తినిపించుకుని ఉంచుకోవడం సూచించండి."
    ]
}

def get_fertilizer_recommendation(crop):
    crop_data = data[data['Crop'].str.lower() == crop.lower()]
    if not crop_data.empty:
        crop_data = crop_data.iloc[0]
    else:
        return ["Crop not found in data."]

    recommendations = []
    if crop_data['N'] > 50:
        recommendations.extend(fertilizer_dic['NHigh'])
    else:
        recommendations.extend(fertilizer_dic['Nlow'])

    if crop_data['P'] > 40:
        recommendations.extend(fertilizer_dic['PHigh'])
    else:
        recommendations.extend(fertilizer_dic['Plow'])

    if crop_data['K'] > 40:
        recommendations.extend(fertilizer_dic['KHigh'])
    else:
        recommendations.extend(fertilizer_dic['Klow'])

    return recommendations

@app.route('/')
def index():
    return render_template('chatbot.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    message = data['message'].lower()

    if 'recommend crop' in message:
        return jsonify({'input_request': 'Please provide the following details: N, P, K, pH, temperature, humidity, and rainfall.'})
    elif 'recommend fertilizer' in message:
        return jsonify({'input_request': 'Please provide the crop name for fertilizer recommendation.'})
    else:
        inputs = message.split(',')
        if len(inputs) == 1:
            crop = inputs[0].strip()
            recommendations = get_fertilizer_recommendation(crop)
            return jsonify({'message': 'Fertilizer recommendations: ' + ' '.join(recommendations)})
        elif len(inputs) == 7:
            try:
                N, P, K, ph, temperature, humidity, rainfall = map(float, inputs)
                scaled_input = scaler.transform([[N, P, K, ph, temperature, humidity, rainfall]])
                predicted_crop = model.predict(scaled_input)
                return jsonify({'message': f'Recommended crop: {predicted_crop[0]}'})
            except ValueError:
                return jsonify({'message': 'Error: Please provide valid numeric values for N, P, K, pH, temperature, humidity, and rainfall.'})
        else:
            return jsonify({'message': 'I did not understand that. Please type "recommend crop" or "recommend fertilizer".'})

@app.route('/get_location_data', methods=['POST'])
def get_location_data():
    data = request.get_json()
    latitude = data['latitude']
    longitude = data['longitude']

    try:
        location = geolocator.reverse((latitude, longitude), exactly_one=True)
        location_name = location.address
        weather_api_key='14a20a42870c19871e751b16f83176a9'

        weather_url = f'http://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={weather_api_key}&units=metric'
        response = requests.get(weather_url)

        if response.status_code == 200:
            weather_data = response.json()
            temperature = weather_data['main']['temp']
            humidity = weather_data['main']['humidity']
            rainfall = weather_data['rain']['1h'] if 'rain' in weather_data else 0

            return jsonify({
                'location_name': location_name,
                'temperature': temperature,
                'humidity': humidity,
                'rainfall': rainfall
            })
        else:
            return jsonify({'error': 'Failed to fetch weather data'}), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
